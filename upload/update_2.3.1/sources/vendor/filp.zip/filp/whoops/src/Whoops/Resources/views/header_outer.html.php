<header>
  <?php $tpl->render($header) ?>
</header>
